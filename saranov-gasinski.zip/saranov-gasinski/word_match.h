#ifndef WORD_MATCH_H
#define WORD_MATCH_H

int word_match(unsigned char *one, unsigned char *two, int number_of_bytes);

#endif // WORD_MATCH_H
